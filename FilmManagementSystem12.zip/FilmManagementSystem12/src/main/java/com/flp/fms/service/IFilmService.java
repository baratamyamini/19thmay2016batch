package com.flp.fms.service;

import java.util.List;
import java.util.ArrayList;

import com.flp.ems.domain.Film;

public interface IFilmService {
	
	String addFilm(List filmDetails);

	boolean removeFilm(Short film_id);

	Film searchFilm(Short film_id);

	List<Film> getAllFilm();


	String  modifyFilm(List filmDetails);



	
	

}
