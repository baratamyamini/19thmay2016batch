package com.flp.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.ems.domain.Actor;

public class ActorDaoImplForList implements IActorDao {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("hello");
	EntityManager em=emf.createEntityManager();
	private String first_name;
	
	public Actor addActor(Actor actor)
	{
		Actor actor1=findActorByName(first_name);
		if(actor1 == null)
		{
			actor1=new Actor();
		}
		em.persist(actor1);
		return actor1;
	}
	
	private Actor findActorByName(String first_name) 
	{
	return em.find(Actor.class, first_name);
    }

	

	public Actor modifyActor(Actor actor) {
		TypedQuery<Actor> query=em.createQuery("Select actor from Actor actor",Actor.class);
		List<Actor> actors=query.getResultList();
		for(Actor detailsFromDb:actors)
		{
			if(detailsFromDb.getFirst_name().equals(actor.getFirst_name())&&detailsFromDb.getLast_name().equals(actor.getLast_name()))
			{
				em.getTransaction().begin();
				em.persist(actor);
				em.getTransaction().commit();
			}
		}
		return actor;
	}

	public boolean removeActor(Short actor_id) {
		Actor actor=searchActor(actor_id);
		if(actor!=null)
		{
			em.remove(actor);
			return true;
		}
		return false;
	}

	public Actor searchActor(Short actor_id) {
		
		return em.find(Actor.class, actor_id);
	}

	public List<Actor> getAllActor() {
		TypedQuery<Actor> query=em.createQuery("Select a from Actor a",Actor.class);
		return query.getResultList();
	}

	

}
