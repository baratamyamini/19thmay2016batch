package com.flp.fms.service;

import java.util.List;
import java.util.ArrayList;

import com.flp.ems.domain.Actor;

public interface IActorService {

	boolean removeActor(Short actor_id);

	String modifyActor(Short actor_id, String first_name, String last_name);

	Object searchActor(Short actor_id);

	List getAllActor();                                                                                                                                                                                                                                                                                                       

	Actor addActor(String first_name, String last_name);

}
