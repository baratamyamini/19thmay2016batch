package com.flp.fms.service;

import java.util.List;

import java.util.ArrayList;
import java.util.Date;

import com.flp.ems.domain.Actor;
import com.flp.ems.domain.Category;
import com.flp.ems.domain.Film;
import com.flp.ems.domain.Language;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;

public class FilmServiceImpl implements IFilmService{

	IFilmDao filmDao;
	
	public FilmServiceImpl() 
	{
	filmDao=new FilmDaoImplForList();

	}
	public FilmServiceImpl(IFilmDao filmDao)
	{
		this.filmDao=filmDao;
	}
	public String addFilm(List filmDetails) {
		Film film=new Film();
				film.setTitle((String) filmDetails.get(0));
				film.setDescription((String) filmDetails.get(1));
				film.setRelease_year((Date) filmDetails.get(2));
				film.setRental_duration((Short) filmDetails.get(3));
				film.setRental_rate((Float) filmDetails.get(4));
				film.setLength((Short) filmDetails.get(5));
				film.setReplacement_cost((Long) filmDetails.get(6));
				film.setRating((Float) filmDetails.get(7));
				film.setSpecial_features((String) filmDetails.get(8));
				Language language=new Language();
				language.setName((String) filmDetails.get(9));
				film.setLanguage(language);
				
				Category category=new Category();
				category.setName((String) filmDetails.get(10));
				film.setCategory(category);
					for(int i=11;i<filmDetails.size();i++)
							{
								Actor actor=new Actor();
						List  actorDetails=(List) filmDetails.get(i);
								actor.setFirst_name((String) actorDetails.get(0));
								actor.setLast_name((String) actorDetails.get(1));
								film.getActors().add(actor);
							}
					return	filmDao.addFilm(film);
			}

			


	public boolean removeFilm(Short film_id) {
		
		 return filmDao.removeFilm(film_id);
	}

	public Film searchFilm(Short film_id) {
		
		return filmDao.searchFilm(film_id);
	}

	public List<Film> getAllFilm() {
		
		return filmDao.getAllFilm();
	}

	

	public String  modifyFilm(List filmDetails) {

		Film film=filmDao.searchFilm((Short)filmDetails.get(0));
		if(film!=null){
		film.setTitle((String) filmDetails.get(1));
		film.setDescription((String) filmDetails.get(2));
		film.setRelease_year((Date) filmDetails.get(3));
		film.setRental_duration((Short) filmDetails.get(4));
		film.setRental_rate((Float) filmDetails.get(5));
		film.setLength((Short) filmDetails.get(6));
		film.setReplacement_cost((Long) filmDetails.get(7));
		film.setRating((Float) filmDetails.get(8));
		film.setSpecial_features((String) filmDetails.get(9));
		
		Language language=new Language();
		language.setName((String) filmDetails.get(10));
		film.setLanguage(language);
		Category category=new Category();
		category.setName((String) filmDetails.get(11));
		film.setCategory(category);
		for(int i=12;i<filmDetails.size();i++)
		{
			Actor actor=new Actor();
			List actorDetails= (List) filmDetails.get(i);
			actor.setFirst_name((String) actorDetails.get(0));
			actor.setLast_name((String) actorDetails.get(1));
			film.getActors().add(actor);
		}
		 filmDao. modifyFilm(film);
		 return "modified";
		
		}
		return "can't modify";
	}
}
	



	

	

	


